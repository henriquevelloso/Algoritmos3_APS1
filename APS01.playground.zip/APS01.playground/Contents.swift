//: # APS 01
//: ### Henrique Velloso
import Cocoa

//: ## Leitura do arquivo.
//var fileName = "example_1"
//var fileName = "example_2"
var fileName = "example_3"
//var fileName = "example_4"

let fileURL = Bundle.main.url(forResource: fileName, withExtension: "txt")
let content = try String(contentsOf: fileURL!, encoding: String.Encoding.utf8)

//: ## Converte o conteudo do arquivo em uma matriz removendo a primeira linha (Header).
var contentArrTemp = content.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).components(separatedBy: "\n")
var contentArr = [[Character]]()
for item in contentArrTemp {
    contentArr.append( Array(item.characters) as [Character])
}
contentArr.removeFirst()

//: ## Pega as informações sobre quantidade de linhas e colunas na primeira linha do arquivo (Header).
let headerLine = contentArrTemp.first!.components(separatedBy: CharacterSet.whitespaces)
let columnsCount = Int(headerLine.first!)!
let rowsCount = Int(headerLine.last!)!


//: ## Monta um nova matriz e duas cópias
var newMatriz = String()
var newMatrizCopiaA = String()
var newMatrizCopiaB = String()

for indexRow in 0..<rowsCount {
    
    newMatriz += "|"
    newMatrizCopiaA += "|"
    newMatrizCopiaB += "|"
    
    for indexCol in 0..<columnsCount {
        
        let value = contentArr[indexRow][indexCol]
        let valueA = value == "1" ? "2" : value
        let valueB = value == "0" ? "2" : value
        
        newMatriz += "\(value)|"
        newMatrizCopiaA += "\(valueA)|"
        newMatrizCopiaB += "\(valueB)|"
        
    }
    newMatriz += "\n"
    newMatrizCopiaA += "\n"
    newMatrizCopiaB += "\n"
}


//: Matriz original

newMatriz



//: Matriz Cópia A - Troca 1 por 2

newMatrizCopiaA



//: Matriz original Cópia B - Troca 0 por 2

newMatrizCopiaB



















